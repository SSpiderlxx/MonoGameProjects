﻿using EngineVersion4.Components;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Project2.Components;
using Project2.Statics;

namespace Engine
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private Texture2D background;
        private Rectangle Rectangle;

        private Player player;
        private Enemy enemy;

        private Map map = new Map();

        Publics publics = new();

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            publics.rootDirectory = Content.RootDirectory;
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            background = Content.Load<Texture2D>("Assets/Enemy");
            player = new Player();
            player.Init(Content, "Assets/Aniamtion");
            enemy = new Enemy();
            enemy.position = new Vector2(200, 200);
            enemy.Init(Content, "Assets/Enemy");

            publics.font = Content.Load<SpriteFont>("Fonts/DefaultFont");

            int[,] MAP = map.LoadMap("level.txt", 8, 5);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            Publics.Instance.inputManager.updatePreviouseMS();

            player.Update(gameTime);
            enemy.Update(gameTime);

            Rectangle = new Rectangle(100, 100, 50, 50);


            foreach (GameObject Object in publics.GameObjectsToInit)
            {
                Object.Init(Content, "");
            }

            foreach (GameObject Object in publics.GameObjectsToUpdate)
            {
                Object.Update(gameTime);
            }

            foreach (Bullet bullet in publics.bulletsToUpdate)
            {
                if(bullet.Texture != Content.Load<Texture2D>("Assets/Player"))
                    bullet.Texture = Content.Load<Texture2D>("Assets/Player");
                bullet.Init(Content, "Assets/Player");

                if (Collision.AABB(bullet, enemy))
                {
                    bullet.Destroy();
                }
                bullet.Update(gameTime);
            }

            for(int i = 0; i < publics.bulletsToRemove.Count; i++)
            {

                Bullet bullet = publics.bulletsToRemove[i];
                publics.bulletsToUpdate.Remove(bullet);
            }

            /*if (Collision.AABB(player.position, Rectangle))
            {
                Rectangle = new Rectangle(200, 100, 50, 50);
            }*/
            

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            _spriteBatch.Begin();

            _spriteBatch.Draw(background, Rectangle, Color.White);

            player.Draw(_spriteBatch);

            enemy.Draw(_spriteBatch);

            foreach(Bullet bullet in publics.bulletsToUpdate)
            {
                bullet.Draw(_spriteBatch);
            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}