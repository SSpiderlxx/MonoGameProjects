﻿using Project2.Statics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using Project2.DataTypes;

namespace EngineVersion4.Components
{
    internal class Map
    {
        Publics publics = Publics.Instance;
        public int[,] LoadMap(string levelname, int sizeX, int sizeY)
        {
            // Get the file path
            string savePath = System.IO.Path.Combine(Environment.CurrentDirectory, "Levels", levelname);

            // Read the file content
            string fileContent = File.ReadAllText(savePath);

            // Parse the file content into a 2D array using regular expressions
            int[,] map = new int[sizeX, sizeY];

            Regex regex = new Regex("[0-9]+");
            MatchCollection matches = regex.Matches(fileContent);

            int index = 0;
            for (int i = 0; i < sizeX; i++)
            {
                for (int j = 0; j < sizeY; j++)
                {
                    map[i, j] = int.Parse(matches[index++].Value);
                }
            }

            return map;

        }

        public void LoadMapDataIntoTileMap(string levelname, int sizeX, int sizeY)
        {
            int[,] map = LoadMap(levelname, sizeX, sizeY);

            Tile[,] tempTileMap = new Tile[sizeX, sizeY];

            for (int x = 0; x < sizeX; x++)
            {
                for (int y = 0; y < sizeY; y++)
                {
                    tempTileMap[x,y].TileID = map[x,y];
                }
            }

        }


    }
}
