﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Project2.Statics;

namespace Project2.Components
{
    public abstract class GameObject
    {

        private Publics Publics = Publics.Instance;

        public Rectangle Rectangle { get; set; }
        public Texture2D Texture { get; set; }

        public Vector2 position = new Vector2(0, 0);
        public Vector2 Scale = new Vector2(1, 1);

        public virtual void Init(ContentManager Content, string TexturePath)
        {
            Texture = Content.Load<Texture2D>(TexturePath);
            Rectangle = new Rectangle(0, 0, Texture.Width, Texture.Height);

            Publics.GameObjectsToUpdate.Add(this);
        }

        public virtual void Update(GameTime gameTime)
        {

        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture, position, Rectangle, Color.White, 0, new Vector2(0.5f, 0.5f), Scale, SpriteEffects.None, 1f);
        }

    }
}
