﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Project2.Components;
using Project2.Statics;

namespace Engine
{
    public class Bullet : Projectile
    {

        public override void Init(ContentManager Content, string TexturePath)
        {
            Rectangle = new Rectangle(0, 0, Texture.Width, Texture.Height);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        public void Destroy()
        {
            Publics.Instance.bulletsToRemove.Add(this);
        }

    }
}
